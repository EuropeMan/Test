#include <imgui.h>
#include <iostream>
#include "features.h"

float lerp(float a, float b, float t) {
    return a + (b - a) * t;
}

bool IsCS2Active(bool onlyCS) {
    HWND hwnd = GetForegroundWindow();
    if (!hwnd) return false;

    char title[256];
    if (GetWindowTextA(hwnd, title, sizeof(title)) == 0) return false;

    std::string windowTitle(title);
    if (onlyCS)
        return windowTitle == "Counter-Strike 2";
    else
        return windowTitle == "Counter-Strike 2" || windowTitle == hackname;
}

double DegToRad(double degrees) {
    return degrees * (PI / 180.0);
}

double RadToDeg(double radians) {
    return radians * (180.0 / PI);
}

bool IsPressed(int key) {
    int nkey = 0;
    if (key == 0) {
        return true;
    }
    switch (key) {
    case 1: nkey = VK_LBUTTON; break;
    case 2: nkey = VK_RBUTTON; break;
    case 3: nkey = VK_MBUTTON; break;
    case 4: nkey = VK_XBUTTON1; break;
    case 5: nkey = VK_XBUTTON2; break;
    case 6: nkey = VK_LMENU; break;     // Alt
    case 7: nkey = VK_LSHIFT; break;
    case 8: nkey = VK_LCONTROL; break;
    case 9: nkey = VK_CAPITAL; break;   // Caps Lock
    default: return false;
    }
    return (GetAsyncKeyState(nkey) & 0x8000);
}

int getzoomlevel() {
    auto local = GetLocalPlayer();
    if (!local) {
        return 0;
    }

    uintptr_t camera = ReadMemory<uintptr_t>(hProc, local + cs2_dumper::schemas::client_dll::C_BasePlayerPawn::m_pCameraServices);
    if (!camera) {
        return 0;
    }

    int fov = ReadMemory<int>(hProc, camera + cs2_dumper::schemas::client_dll::CCSPlayerBase_CameraServices::m_iFOV);
    bool inscope = ReadMemory<bool>(hProc, local + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_bIsScoped);


    if (!inscope) return 0;
    if (fov == 90) return 0;
    if (fov == 40) return 1;
    if (fov == 15) return 2;
    return 3;
}

float getzoomscale() {
    int level = getzoomlevel();
    float out = 1.0f;
    if (level == 1) out = 2.25f;
    if (level == 2) out = 6.0f;
    if (level == 3) out = 2.0f;
    return out;
}

void movemouse(float needx, float needy) {
    Vec3 cur = GetViewAngles();

    float x = needx - cur.x;
    float y = needy - cur.y;

    float dx = x / (sens * cfg.m_yaw);
    float dy = y / (sens * cfg.m_pitch);

    float scale = getzoomscale();
    dx *= scale;
    dy *= scale;

    mouse_event(MOUSEEVENTF_MOVE, -int(dy), int(dx), 0, 0);
}
std::pair<float, float> getxybypy(float needx, float needy) {
    Vec3 cur = GetViewAngles();

    float x = needx - cur.x;
    float y = needy - cur.y;

    float dx = x / (cfg.m_yaw);
    float dy = y / (cfg.m_pitch);

    dx = dx + (float)ScreenW / 2;
    dy = dy + (float)ScreenH / 2;

    return {-dy, dx};
}

void mousedown() {
    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
}
void mouseup() {
    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}

uintptr_t ParseHexToUintptr(const char* str)
{
    if (!str || *str == '\0')
        return 0;

    char* endptr;
    uint64_t value = std::strtoull(str, &endptr, 0);
    if (*endptr != '\0')
        return 0;

    return static_cast<uintptr_t>(value);
}

std::unordered_map< int, char > m_weapon_icons =
{
        { 1, 'A' },
        { 2, 'B' },
        { 3, 'C' },
        { 4, 'D' },
        { 7, 'W' },
        { 8, 'U' },
        { 9, 'Z' },
        { 10, 'R' },
        { 11, 'X' },
        { 13, 'Q' },
        { 14, 'g' },
        { 16, 'S' },
        { 17, 'K' },
        { 19, 'P' },
        { 0, 'N' },
        { 24, 'L' },
        { 25, 'b' },
        { 26, 'M' },
        { 27, 'd' },
        { 28, 'f' },
        { 29, 'c' },
        { 30, 'H' },
        { 31, 'h' },
        { 32, 'E' },
        { 33, 'E' },
        { 34, 'O' },
        { 35, 'e' },
        { 36, 'F' },
        { 38, 'Y' },
        { 39, 'V' },
        { 40, 'a' },
        { 42, '[' },
        { 43, 'i' },
        { 44, 'j' },
        { 45, 'k' },
        { 46, 'l' },
        { 47, 'm' },
        { 48, 'n' },
        { 49, 'o' },
        { 59, '[' },
        { 60, 'T' },
        { 61, 'G' },
        { 63, 'I' },
        { 64, 'J' },
        { 500, '1' },
        { 505, '2' },
        { 506, '3' },
        { 507, '4' },
        { 508, '5' },
        { 509, '6' },
        { 512, '0' },
        { 514, '7' },
        { 515, '8' },
        { 516, '9' },
        { 526, '[' },
};

double PI = 3.14159265358979323846;
const char* const aimkeys[] = { "NoKey", "Mouse1","Mouse2","Mouse3","Mouse4","Mouse5","Alt","Shift","Ctrl","CapsLock" };
int off = 16777472;
int on = 65537;
bool firstaa = true;
bool aatogled = false;
Vec3 startang = Vec3(0.0f, 0.0f, 0.0f);
bool first = true;