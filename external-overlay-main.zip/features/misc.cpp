#include "features.h"

std::string fullPath = "";

void DownloadHitSound() {
    const char* url = "https://github.com/EuropeMan/Test/raw/refs/heads/main/hitsound.wav";
    const char* folder = "hitsounds";
    const char* file = "hitsound.wav";

    if (!std::filesystem::exists(folder)) {
        std::filesystem::create_directory(folder);
    }

    fullPath = std::string(folder) + "\\" + file;

    HRESULT hr = URLDownloadToFileA(nullptr, url, fullPath.c_str(), 0, nullptr);
    /*if (hr == S_OK) {
        MessageBoxA(nullptr, "���� ������� ������", "�����", MB_OK);
    }
    else {
        MessageBoxA(nullptr, "�� ������� ������� ����", "������", MB_OK);
    }*/
}

void setVolume(int percent) {
    percent = max(0, min(100, percent)); // clamp
    DWORD volume = (DWORD)((percent / 100.0) * 0xFFFF); // 0 - 0xFFFF
    DWORD bothChannels = (volume & 0xFFFF) | ((volume & 0xFFFF) << 16);
    waveOutSetVolume(0, bothChannels);
}

void PlayHitSound() {
    PlaySoundA(fullPath.c_str(), nullptr, SND_FILENAME | SND_ASYNC);
}
uintptr_t bullet = ReadMemory<uintptr_t>(hProc, GetLocalPlayer() + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_pBulletServices);
int hits = ReadMemory<int>(hProc, bullet + cs2_dumper::schemas::client_dll::CCSPlayer_BulletServices::m_totalHitsOnServer);;

void misc::misc() {
    DownloadHitSound();
    if (IsCS2Active(true)) {
        if (cfg.misc_bunnyhop) {
            if (GetAsyncKeyState(VK_SPACE)) {
                int flags = ReadMemory<int>(hProc, GetLocalPlayer() + cs2_dumper::schemas::client_dll::C_BaseEntity::m_fFlags);
                //bool onground = ReadMemory<bool>(hProc, GetLocalPlayer() + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_bOnGroundLastTick);
                if (flags & (1 << 0)) {
                    WriteMemory<int>(hProc, clientBase + 0x184BE00, on);
                    Sleep(5);
                    WriteMemory<int>(hProc, clientBase + 0x184BE00, off);
                }
            }
        }
    }
    uintptr_t lp = GetLocalPlayer();
    if (!lp)
        return;
    WriteMemory<float>(hProc, lp + cs2_dumper::schemas::client_dll::C_CSPlayerPawnBase::m_flFlashMaxAlpha, (cfg.misc_antiflash ? 0.0f : 255.0f));
    uintptr_t bullet = ReadMemory<uintptr_t>(hProc, lp + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_pBulletServices);
    int newhits = ReadMemory<int>(hProc, bullet + cs2_dumper::schemas::client_dll::CCSPlayer_BulletServices::m_totalHitsOnServer);
    if (newhits < 0 || newhits > 10000)
        return;
    if (newhits > hits) {
        if (cfg.misc_hsen) {
            int hp = GetHP(lp);
            if (hp < 0 || hp > 100)
                return;
            setVolume(cfg.misc_hsvol);
            PlayHitSound();
            hits = newhits;
        }
    }
    else if (newhits < hits) {
        hits = newhits;
    }
}

DWORD WINAPI misc::thread(LPVOID lpParam) {
    while (true) {
        Sleep(5);
        misc::misc();
    }
}