#pragma once
#include <Windows.h>
#include <string>

DWORD GetProcessIdByName(const std::wstring& processName);
uintptr_t GetModuleBaseAddress(DWORD pid, const std::wstring& modName);
extern DWORD pid;
extern HANDLE hProc;
extern uintptr_t clientBase;
template<typename T>
T ReadMemory(HANDLE hProc, uintptr_t addr) {
    T buffer;
    ReadProcessMemory(hProc, (LPCVOID)addr, &buffer, sizeof(T), nullptr);
    return buffer;
}

template<typename T>
void WriteMemory(HANDLE hProc, uintptr_t addr, const T& value) {
    WriteProcessMemory(hProc, (LPVOID)addr, &value, sizeof(T), nullptr);
}