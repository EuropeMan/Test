#include "features.h"

uintptr_t target = 0;
bool started = false;
const char* const hitboxes[] = { "Head", "Body" };

int GetHitbox(int hit) {
    int hitbox = 6;
    switch (hit) {
    case 0: hitbox = 6; break;
    case 1: hitbox = 1; break;
    default: return hitbox;
    }
    return hitbox;
}

void doaim(float pitch, float yaw) {
    if (cfg.aim_silent) {
        WriteMemory<float>(hProc, 0x10150, pitch);
        WriteMemory<float>(hProc, 0x10154, yaw);
    }
    else {
        movemouse(pitch, yaw);
    }
}

void attack() {
    mousedown();
    Sleep(5);
    mouseup();
}

void doautofire(LPVOID lpParam) {
    started = true;
    Vec3* start = reinterpret_cast<Vec3*>(lpParam);
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    attack();

    started = false;

    delete start;
}

bool find_target() {
    int bestdist = cfg.aim_fov == 0.0f ? 999999 : static_cast<int>(cfg.aim_fov);
    bool found = false;
    uintptr_t tempplayer = 0;
    std::vector<uintptr_t> players = GetAllPlayers();
    for (uintptr_t playerAddr : players) {
        bool immunity = ReadMemory<bool>(hProc, playerAddr + cs2_dumper::schemas::client_dll::C_CSPlayerPawnBase::m_bGunGameImmunity);
        if ((cfg.aim_tc ? GetTeam(playerAddr) != GetTeam(GetLocalPlayer()) : true) && GetHP(playerAddr) > 0 && playerAddr != GetLocalPlayer() && !immunity) {
            Vec3 pos = GetBonePos(playerAddr, 1);
            Vec2 tp = w2s(pos);
            float dis = Vec2(static_cast<float>(ScreenW) / 2, static_cast<float>(ScreenH) / 2).distance(tp);
            if (dis < bestdist) {
                bestdist = static_cast<int>(dis);
                tempplayer = playerAddr;
                found = true;
            }
        }
    }
    target = tempplayer;
    return found;
}
void aimbot::AimBot() {
    bool afirst = true;
    Vec3 start = Vec3(0.0f, 0.0f, 0.0f);
    Vec3 aimang = Vec3(0.0f, 0.0f, 0.0f);
    Vec3 oldang = Vec3(0.0f, 0.0f, 0.0f);
    if (IsCS2Active(true)) {
        if (cfg.aim_enabled) {
            if (IsPressed(cfg.aim_key)) {
                if (target == 0) {
                    find_target();
                    return;
                }
                if (afirst) {
                    start = GetViewAngles();
                    aimang = start;
                    afirst = false;
                }
                if (GetHP(target) > 0) {
                    Vec3 campos = GetCamPos(GetLocalPlayer());
                    Vec3 bone = GetBonePos(target, GetHitbox(cfg.aim_hitbox));
                    Vec3 bonescr = (bone - campos).to_angle();
                    //WriteMemory<float>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwViewAngles, bonescr.x);
                    //WriteMemory<float>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwViewAngles + 4, bonescr.y);

                    Vec3 punch = Vec3(0, 0, 0);
                    if (cfg.aim_recoilcs && GetAsyncKeyState(VK_LBUTTON)) {
                        bool attackk = ReadMemory<bool>(hProc, clientBase + clientBase + cs2_dumper::buttons::attack);
                        punch = GetPunchAngle(GetLocalPlayer());
                        bonescr = bonescr - punch * 2;
                    }
                    if (cfg.aim_smooth == 0) {
                        aimang.x = bonescr.x;
                        aimang.y = bonescr.y;
                    }
                    else {
                        Vec3 viewang = GetViewAngles();
                        aimang.x = lerp(viewang.x, bonescr.x, (1.0f - (float)cfg.aim_smooth / 100.0f));
                        aimang.y = lerp(viewang.y, bonescr.y, (1.0f - (float)cfg.aim_smooth / 100.0f));
                    }

                    if (cfg.aim_autofire) {
                        if (CanFireActiveWep()) {
                            doaim(aimang.x, aimang.y);
                            if (!started) {
                                Vec3* start_copy = new Vec3(start);
                                CreateThread(0, 0, (LPTHREAD_START_ROUTINE)doautofire, start_copy, 0, 0);
                            }
                        }
                    }
                    else {
                        doaim(aimang.x, aimang.y);
                    }

                    if (cfg.aim_swhenstop) {
                        if (GetVelocity(GetLocalPlayer()).to_length() < 50) {
                            if (CanFireActiveWep()) {
                                doaim(aimang.x, aimang.y);
                                if (!started) {
                                    Vec3* start_copy = new Vec3(start);
                                    CreateThread(0, 0, (LPTHREAD_START_ROUTINE)doautofire, start_copy, 0, 0);
                                }
                            }
                        }
                    }
                    oldang = GetViewAngles();
                }
                else {
                    if (!cfg.aim_donkill) {
                        find_target();
                    }
                }
            }
            else {
                if (!afirst) {
                    afirst = true;
                }
                if (cfg.aim_silent) {
                    Vec3 va = GetViewAngles();
                    doaim(va.x, va.y);
                }
                find_target();
            }
        }
        else {
            target = 0;
        }
    }
}
DWORD WINAPI aimbot::thread(LPVOID lpParam) {
    while (true) {
        Sleep(5);
        aimbot::AimBot();
    }
}