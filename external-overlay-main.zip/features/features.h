#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
#include <cmath>
#include <vector>
#include "../src/offsets.h"
#include <numbers>
#include "../src/client_dll.h"
#include <thread>
#include <chrono>
#include <unordered_map>
#include <fstream>
#include <filesystem>
#include <algorithm>
#include "../src/buttons.h"
#include "../src/json.hpp"
#include "../src/tinyformat.h"
#include "../src/overlay.h"
#include "wallhack.h"
#include "aimbot.h"
#include "trigger.h"
#include "misc.h"
#include <urlmon.h>
#include <shlobj.h>
#include <vectors/vectors.h>
#include <entities/entities.h>
#include <mmsystem.h>
#include <config/config.h>
#include <memory/memory.h>
#include <speclist.h>
#include <vars/vars.h>
#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "winmm.lib")

extern Vec3 startang;

float lerp(float a, float b, float t);
bool IsCS2Active(bool onlyCS = false);

extern bool first;

extern std::unordered_map< int, char > m_weapon_icons;
extern const char* const aimkeys[];

extern double PI;
double DegToRad(double degrees);
double RadToDeg(double radians);
uintptr_t ParseHexToUintptr(const char* str);

extern int off;
extern int on;
extern bool firstaa;
extern bool aatogled;


std::pair<float, float> getxybypy(float needx, float needy);
bool IsPressed(int key);
int getzoomlevel();
float getzoomscale();
void movemouse(float needx, float needy);
void mousedown();
void mouseup();