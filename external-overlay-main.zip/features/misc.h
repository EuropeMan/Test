#pragma once
namespace misc {
	void misc();
	DWORD WINAPI thread(LPVOID lpParam);
}