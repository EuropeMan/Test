#include <features.h>

int ScreenW = GetSystemMetrics(SM_CXSCREEN);
int ScreenH = GetSystemMetrics(SM_CYSCREEN);

const char* hackname = "XeatWare";
float sens = 4.0f;