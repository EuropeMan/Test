#include <features.h>
DWORD GetProcessIdByName(const std::wstring& processName) {
    PROCESSENTRY32 entry{};
    entry.dwSize = sizeof(PROCESSENTRY32);

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;

    if (Process32First(snapshot, &entry)) {
        do {
            if (processName == entry.szExeFile) {
                CloseHandle(snapshot);
                return entry.th32ProcessID;
            }
        } while (Process32Next(snapshot, &entry));
    }

    CloseHandle(snapshot);
    return 0;
}

uintptr_t GetModuleBaseAddress(DWORD pid, const std::wstring& modName) {
    MODULEENTRY32 modEntry{};
    modEntry.dwSize = sizeof(MODULEENTRY32);
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);

    if (Module32First(snapshot, &modEntry)) {
        do {
            if (modName == modEntry.szModule) {
                CloseHandle(snapshot);
                return reinterpret_cast<uintptr_t>(modEntry.modBaseAddr);
            }
        } while (Module32Next(snapshot, &modEntry));
    }

    CloseHandle(snapshot);
    return 0;
}

DWORD pid = GetProcessIdByName(L"cs2.exe");
HANDLE hProc = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION, FALSE, pid);
uintptr_t clientBase = GetModuleBaseAddress(pid, L"client.dll");