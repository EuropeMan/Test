#include <features.h>

int GetTeam(uintptr_t pawn) {
    return ReadMemory<int>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iTeamNum);
}

uintptr_t GetLocalPlayer() {
    return ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwLocalPlayerPawn);
}

uintptr_t GetLocalPlayerController() {
    return ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwLocalPlayerController);
}

int GetHP(uintptr_t pawn) {
    try {
        int hp = ReadMemory<int>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iHealth);
        return (hp > -1 ? hp : 0);
    }
    catch (...) {
        return 0;
    }
}

int GetMaxHP(uintptr_t pawn) {
    return ReadMemory<int>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iMaxHealth);
}

int GetArmor(uintptr_t pawn) {
    return ReadMemory<int>(hProc, pawn + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_ArmorValue);
}

uintptr_t GetController(uintptr_t pawn) {
    uintptr_t EntList = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwEntityList);
    uintptr_t m_hController = ReadMemory<uintptr_t>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BasePlayerPawn::m_hController);
    uintptr_t controller_index = m_hController & 0x7FFF;
    uintptr_t dwListEntityPtr = ReadMemory<uintptr_t>(hProc, EntList + 0x8 * (controller_index >> 9) + 16);
    return ReadMemory<uintptr_t>(hProc, dwListEntityPtr + 120 * (controller_index & 0x1FF));
}

uintptr_t GetPawn(uintptr_t controller) {
    uintptr_t EntList = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwEntityList);
    uintptr_t m_hPlayerPawn = ReadMemory<uintptr_t>(hProc, controller + cs2_dumper::schemas::client_dll::CBasePlayerController::m_hPawn);
    uintptr_t dwListEntityPtr = ReadMemory<uintptr_t>(hProc, EntList + 8 * ((m_hPlayerPawn & 0x7FFF) >> 9) + 16);
    return ReadMemory<uintptr_t>(hProc, dwListEntityPtr + 120 * (m_hPlayerPawn & 0x1FF));
}
std::string GetName(uintptr_t pawn) {
    try {
        char nameBuffer[128]{};
        ReadProcessMemory(
            hProc,
            (LPCVOID)(GetController(pawn) + cs2_dumper::schemas::client_dll::CBasePlayerController::m_iszPlayerName),
            nameBuffer,
            sizeof(nameBuffer),
            nullptr
        );
        return std::string(nameBuffer);
    }
    catch (...) {
        return "";
    }
}

std::string GetNameForce(uintptr_t ctrl) {
    try {
        char nameBuffer[128]{};
        ReadProcessMemory(
            hProc,
            (LPCVOID)(ctrl + cs2_dumper::schemas::client_dll::CBasePlayerController::m_iszPlayerName),
            nameBuffer,
            sizeof(nameBuffer),
            nullptr
        );
        return std::string(nameBuffer);
    }
    catch (...) {
        return "";
    }
}

int GetActiveWeaponID(uintptr_t pawn) {
    uintptr_t weaponptr = ReadMemory<uintptr_t>(hProc, pawn + cs2_dumper::schemas::client_dll::C_CSPlayerPawnBase::m_pClippingWeapon);
    return ReadMemory<int>(hProc, weaponptr + cs2_dumper::schemas::client_dll::C_EconEntity::m_AttributeManager
        + cs2_dumper::schemas::client_dll::C_AttributeContainer::m_Item
        + cs2_dumper::schemas::client_dll::C_EconItemView::m_iItemDefinitionIndex);
}

std::vector<std::pair<uintptr_t, uintptr_t>> GetAllPlayersFull() {
    std::vector<std::pair<uintptr_t, uintptr_t>> plyes;

    try {
        uintptr_t EntList = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwEntityList);

        for (int i = 0; i < 64; i++) {
            try {
                uintptr_t dwEntityPtr = ReadMemory<uintptr_t>(hProc, EntList + (8 * (i & 0x7FFF) >> 9) + 16);
                uintptr_t dwControllerPtr = ReadMemory<uintptr_t>(hProc, dwEntityPtr + 120 * (i & 0x1FF));
                uintptr_t pawn = GetPawn(dwControllerPtr);
                if (!pawn) {
                    pawn = 0x0;
                }
                plyes.emplace_back(dwControllerPtr, pawn);
            }
            catch (...) {}
        }
    }
    catch (...) {}

    return plyes;
}

std::vector<uintptr_t> playerlist = { GetLocalPlayer() };
std::vector<uintptr_t> playerlistct = { GetLocalPlayer() };

std::vector<uintptr_t> GetAllPlayers(bool controllers) {
    return controllers ? playerlistct : playerlist;
}

Vec3 GetBonePos(uintptr_t pawn, int bone) {
    uintptr_t game_scene = ReadMemory<uintptr_t>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BaseEntity::m_pGameSceneNode);
    uintptr_t bone_matrix = ReadMemory<uintptr_t>(hProc, game_scene + cs2_dumper::schemas::client_dll::CSkeletonInstance::m_modelState + 0x80);

    return ReadMemory<Vec3>(hProc, bone_matrix + bone * 0x20);
}

Vec3 GetVelocity(uintptr_t pawn) {
    return ReadMemory<Vec3>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BaseEntity::m_vecAbsVelocity);
}

Vec3 GetCamPos(uintptr_t pawn) {
    return ReadMemory<Vec3>(hProc, pawn + cs2_dumper::schemas::client_dll::C_CSPlayerPawnBase::m_vecLastClipCameraPos);
}

Vec3 GetPunchAngle(uintptr_t pawn) {
    return ReadMemory<Vec3>(hProc, pawn + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_aimPunchAngle);
}

bool CanFireActiveWep() {
    uintptr_t wepptr = ReadMemory<uintptr_t>(hProc, GetLocalPlayer() + cs2_dumper::schemas::client_dll::C_CSPlayerPawnBase::m_pClippingWeapon);
    int weapontick = ReadMemory<int>(hProc, wepptr + cs2_dumper::schemas::client_dll::C_BasePlayerWeapon::m_nNextPrimaryAttackTick);
    uintptr_t globalsptr = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwGlobalVars);
    int servertick = ReadMemory<int>(hProc, globalsptr + 0x48);
    return servertick > weapontick;
}

uintptr_t GetTracePlayer() {
    uintptr_t localpawn = GetLocalPlayer();
    int EntID = ReadMemory<int>(hProc, localpawn + cs2_dumper::schemas::client_dll::C_CSPlayerPawnBase::m_iIDEntIndex);
    uintptr_t EntList = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwEntityList);
    uintptr_t list_entry = ReadMemory<uintptr_t>(hProc, EntList + 0x8 * (EntID >> 9) + 0x10);
    uintptr_t entity = ReadMemory<uintptr_t>(hProc, list_entry + 120 * (EntID & 0x1FF));
    int m_iTeamNum = ReadMemory<int>(hProc, entity + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iTeamNum);
    if (m_iTeamNum == 3 || m_iTeamNum == 2) {
        return entity;
    }
    return 0;
}

Vec3 GetPos(uintptr_t pawn) {
    try {
        uintptr_t gamenode = ReadMemory<uintptr_t>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BaseEntity::m_pGameSceneNode);
        Vec3 pos = ReadMemory<Vec3>(hProc, gamenode + cs2_dumper::schemas::client_dll::CGameSceneNode::m_vecOrigin);
        return pos;
    }
    catch (...) {
        return Vec3(0.0f, 0.0f, 0.0f);
    }
}

uintptr_t get_pcs_player(uintptr_t address) {
    uintptr_t EntList = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwEntityList);
    uintptr_t list2 = ReadMemory<uintptr_t>(hProc, EntList + 0x8 * ((address & 0x7FFF) >> 9) + 16);
    return ReadMemory<uintptr_t>(hProc, list2 + 120 * (address & 0x1FF));
}

uintptr_t get_spec_player(uintptr_t controller) {
    try {
        uint64_t prepawn = ReadMemory<uint64_t>(hProc, controller + cs2_dumper::schemas::client_dll::CBasePlayerController::m_hPawn);
        uintptr_t pawn = get_pcs_player(prepawn);
        uintptr_t service = ReadMemory<uintptr_t>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BasePlayerPawn::m_pObserverServices);
        uint64_t target = ReadMemory<uint64_t>(hProc, service + cs2_dumper::schemas::client_dll::CPlayer_ObserverServices::m_hObserverTarget);
        uintptr_t tpawn = get_pcs_player(target);
        return tpawn;
    }
    catch (...) {
        return 0x0;
    }
}

std::vector<std::pair<uintptr_t, uintptr_t>> GetSpecList() {
    std::vector<std::pair<uintptr_t, uintptr_t>> specList;
    std::vector<uintptr_t> players = GetAllPlayers(true);
    for (uintptr_t playerAddr : players) {
        uintptr_t specplayer = get_spec_player(playerAddr);
        if (specplayer != 0x0 && playerAddr != 0x0) {
            specList.emplace_back(playerAddr, specplayer);
        }
    }
    return specList;
}

Vec3 GetViewAngles() {
    return ReadMemory<Vec3>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwViewAngles);
}

bool OnGround(uintptr_t pawn) {
    return ReadMemory<bool>(hProc, pawn + cs2_dumper::schemas::client_dll::C_CSPlayerPawn::m_bOnGroundLastTick);
}

void CachePlayers() {
    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        auto players = GetAllPlayersFull();
        playerlist.clear();
        playerlistct.clear();

        for (const auto& [controller, specTarget] : players) {
            playerlistct.push_back(controller);
            playerlist.push_back(specTarget);
        }
    }
}