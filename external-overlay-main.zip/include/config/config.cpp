#include <features.h>

std::vector<std::string> configNames;
std::vector<const char*> configPointers;
Config cfg;

void RefreshConfigList() {
    configNames.clear();
    configPointers.clear();

    std::filesystem::create_directories("cfgs");

    for (const auto& entry : std::filesystem::directory_iterator("cfgs")) {
        if (entry.is_regular_file() && entry.path().extension() == ".bin") {
            configNames.push_back(entry.path().stem().string()); // ��� .bin
        }
    }

    for (const auto& name : configNames) {
        configPointers.push_back(name.c_str());
    }
}


void SaveConfig(const Config& cfg, const char* filename) {
    if (strlen(filename) == 0) return; // ������ �� ������� �����

    std::filesystem::create_directories("cfgs");
    std::string path = "cfgs/";
    path += filename;
    path += ".bin";

    std::ofstream out(path, std::ios::binary);
    if (out.is_open()) {
        out.write(reinterpret_cast<const char*>(&cfg), sizeof(cfg));
        out.close();
    }
}

bool LoadConfig(Config& cfg, const char* filename) {
    if (strlen(filename) == 0) return false;

    std::string path = "cfgs/";
    path += filename;
    path += ".bin";

    std::ifstream in(path, std::ios::binary);
    if (in.is_open()) {
        in.read(reinterpret_cast<char*>(&cfg), sizeof(cfg));
        in.close();
        return true;
    }
    return false;
}