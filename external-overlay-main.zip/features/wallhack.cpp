#include "features.h"

void wallhack::Render()
{
    /*if (GetAsyncKeyState(VK_MBUTTON)) {
        if (firstaa) {
            aatogled = !aatogled;
            startang = ReadMemory<Vec3>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwViewAngles);
            firstaa = false;
        }
        Vec3 view = ReadMemory<Vec3>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwViewAngles);
        view.x = 88.0f;
        view.y = view.y + 180.0f;
        doaim(view.x, view.y);
    }
    else {
        if (!firstaa) {
            doaim(startang.x, startang.y);
            firstaa = true;
        }
    }*/
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (IsCS2Active()) {
        if (cfg.aim_sfov) {
            draw->AddCircle(ImVec2(static_cast<float>(ScreenW) / 2, static_cast<float>(ScreenH) / 2),
                cfg.aim_fov, IM_COL32(255, 255, 255, 255));
        }

        if (cfg.esp_enabled) {
            std::vector<uintptr_t> players = GetAllPlayers();
            Vec3 campos = GetCamPos(GetLocalPlayer());
            Vec3 viewangle = GetViewAngles();
            for (uintptr_t playerAddr : players) {
                bool specing = get_spec_player(GetLocalPlayerController()) == playerAddr;
                if ((cfg.esp_tc ? GetTeam(playerAddr) != GetTeam(GetLocalPlayer()) : true) && GetHP(playerAddr) > 0 && !specing) {
                    Vec3 headp = GetBonePos(playerAddr, 6);
                    Vec2 head = w2s(Vec3(headp.x, headp.y, headp.z + 8));
                    Vec2 leg = w2s(GetBonePos(playerAddr, 28));
                    if (head.x<0 || head.x>ScreenW || head.y<0 || head.y>ScreenH) {
                        continue;
                    }

                    float dist = head.distance(leg);
                    //std::cout << dist << std::endl;
                    ImColor color;
                    if (cfg.esp_ctarget) {
                        color = (target == playerAddr ? IM_COL32(255, 0, 0, 255) : IM_COL32(255, 255, 255, 255));
                    }
                    else {
                        color = IM_COL32(255, 255, 255, 255);
                    }
                    //auto [dx, dy] = getxybypy(0.0f, 0.0f);
                    //draw->AddLine(ImVec2(ScreenW/2, ScreenH/2), ImVec2(dx, dy), color, 1.0f);
                    //draw->AddLine(ImVec2(head.x, head.y+dist), ImVec2(ScreenW/2,ScreenH), color, 1.0f);
                    if (cfg.esp_box) {
                        draw->AddLine(ImVec2(head.x - dist / 4, head.y), ImVec2(head.x - dist / 8, head.y), color, 1.0f);
                        draw->AddLine(ImVec2(head.x - dist / 4, head.y), ImVec2(head.x - dist / 4, head.y + dist / 4), color, 1.0f);

                        draw->AddLine(ImVec2(head.x + dist / 4, head.y), ImVec2(head.x + dist / 8, head.y), color, 1.0f);
                        draw->AddLine(ImVec2(head.x + dist / 4, head.y), ImVec2(head.x + dist / 4, head.y + dist / 4), color, 1.0f);

                        draw->AddLine(ImVec2(head.x - dist / 4, head.y + dist), ImVec2(head.x - dist / 8, head.y + dist), color, 1.0f);
                        draw->AddLine(ImVec2(head.x - dist / 4, head.y + dist), ImVec2(head.x - dist / 4, head.y + dist - dist / 4), color, 1.0f);

                        draw->AddLine(ImVec2(head.x + dist / 4, head.y + dist), ImVec2(head.x + dist / 8, head.y + dist), color, 1.0f);
                        draw->AddLine(ImVec2(head.x + dist / 4, head.y + dist), ImVec2(head.x + dist / 4, head.y + dist - dist / 4), color, 1.0f);
                    }
                    if (cfg.esp_names) {
                        std::string name = GetName(playerAddr);
                        ImVec2 textSize = ImGui::CalcTextSize(name.c_str());
                        draw->AddText(ImVec2(head.x - textSize.x / 2, head.y - 20), color, name.c_str());
                    }
                    if (cfg.esp_hp) {
                        std::string health = std::to_string(GetHP(playerAddr));
                        ImVec2 textSize = ImGui::CalcTextSize(health.c_str());
                        draw->AddText(ImVec2(head.x - textSize.x - dist / 4 - 10, head.y), IM_COL32(0, 255, 0, 255), health.c_str());
                    }
                    if (cfg.esp_hpbar) {
                        int health = GetHP(playerAddr);
                        int maxhealth = GetMaxHP(playerAddr);
                        float vrhp = (float)health / (float)maxhealth;
                        draw->AddRect(ImVec2(head.x - dist / 4 - 4, head.y + (dist - vrhp * dist)), ImVec2(head.x - dist / 4 - 2, head.y + dist), IM_COL32(0, 255, 0, 255), 5.0f, 0, 2.0f);
                    }
                    if (cfg.esp_weapon) {
                        int id = GetActiveWeaponID(playerAddr);
                        ImGui::PushFont(overlay::weaponFont);
                        std::string icon = tfm::format(("%c"), m_weapon_icons[id]);
                        auto text_size = ImGui::CalcTextSize(icon.c_str());
                        draw->AddText(ImVec2(head.x - text_size.x / 2, head.y + dist), IM_COL32(255, 255, 255, 255), icon.c_str());
                        ImGui::PopFont();
                    }
                    ImU32 c = (cfg.darkmode ? 25 : 255);
                    ImU32 c2 = (cfg.darkmode ? 255 : 25);
                    if (cfg.aim_tname && GetHP(GetLocalPlayer())) {
                        Vec2 tpos = Vec2((float)ScreenW / 2.0f, (float)ScreenH / 3.0f);
                        std::string name = GetName(target);
                        if (name != "") {
                            std::string text = "Target: " + name;
                            ImVec2 textsize = ImGui::CalcTextSize(text.c_str());
                            draw->AddRectFilled(ImVec2(tpos.x - textsize.x / 2 - 5, tpos.y - textsize.y / 2 - 5),
                                ImVec2(tpos.x + textsize.x / 2 + 5, tpos.y + textsize.y * 1.1f),
                                IM_COL32(c, c, c, 255), 10.0f);

                            draw->AddText(ImVec2(tpos.x - textsize.x / 2, tpos.y - textsize.y / 2), IM_COL32(c2, c2, c2, 255), text.c_str());
                        }
                    }
                    if (cfg.esp_oov && GetHP(GetLocalPlayer())) {
                        if (head.x < 0 || head.x > ScreenW || head.y < 0 || head.y > ScreenH) {
                            Vec3 pos = GetPos(playerAddr);
                            Vec3 ghead = Vec3(pos.x - campos.x, pos.y - campos.y, 0.0f);
                            ghead = ghead.to_angle();
                            float x = ScreenW / 2 - (float)(std::sin(DegToRad(ghead.y - viewangle.y)) * 250.0f);
                            float y = ScreenH / 2 - (float)(std::cos(DegToRad(ghead.y - viewangle.y)) * 250.0f);
                            draw->AddCircle(ImVec2(x, y), 20, color);
                            std::string name = GetName(playerAddr);
                            ImVec2 textsize = ImGui::CalcTextSize(name.c_str());
                            draw->AddText(ImVec2(x - textsize.x / 2, y - textsize.y / 2), color, name.c_str());
                        }
                    }
                }
            }
        }
    }

    /*ImVec2 head = ImVec2(900, 300);
    ImVec2 feet = ImVec2(900, 500);
    float height = feet.y - head.y;
    float width = height / 2.4f;

    draw->AddRect(
        ImVec2(head.x - width / 2, head.y),
        ImVec2(head.x + width / 2, feet.y),
        IM_COL32(255, 0, 0, 255),
        0.0f, 0, 2.0f
    );

    draw->AddLine(
        ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y),
        ImVec2(head.x, feet.y),
        IM_COL32(0, 255, 0, 255),
        1.0f
    );

    draw->AddText(
        ImVec2(head.x - 20, head.y - 15),
        IM_COL32(255, 255, 255, 255),
        "Enemy"
    );*/
}