#pragma once
#include <vector>
extern std::vector<uintptr_t> playerlist;
extern std::vector<uintptr_t> playerlistct;

int GetTeam(uintptr_t pawn);
uintptr_t GetLocalPlayer();
uintptr_t GetLocalPlayerController();
int GetHP(uintptr_t pawn);
int GetMaxHP(uintptr_t pawn);
int GetArmor(uintptr_t pawn);
uintptr_t GetController(uintptr_t pawn);
uintptr_t GetPawn(uintptr_t controller);
std::string GetName(uintptr_t pawn);
std::string GetNameForce(uintptr_t ctrl);
int GetActiveWeaponID(uintptr_t pawn);
std::vector<std::pair<uintptr_t, uintptr_t>> GetAllPlayersFull();
std::vector<uintptr_t> GetAllPlayers(bool controllers = false);
Vec3 GetBonePos(uintptr_t pawn, int bone);
Vec3 GetVelocity(uintptr_t pawn);
Vec3 GetCamPos(uintptr_t pawn);
Vec3 GetPunchAngle(uintptr_t pawn);
bool CanFireActiveWep();
uintptr_t GetTracePlayer();
Vec3 GetPos(uintptr_t pawn);
uintptr_t get_pcs_player(uintptr_t address);
uintptr_t get_spec_player(uintptr_t controller);
std::vector<std::pair<uintptr_t, uintptr_t>> GetSpecList();
Vec3 GetViewAngles();
void CachePlayers();
bool OnGround(uintptr_t pawn);