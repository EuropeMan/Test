#pragma once
extern int ScreenW;
extern int ScreenH;

extern const char* hackname;
extern float sens;