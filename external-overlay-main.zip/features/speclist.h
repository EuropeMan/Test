#pragma once
#include <vector>

uintptr_t get_pcs_player(uintptr_t address);
uintptr_t get_spec_player(uintptr_t controller);
std::vector<std::pair<uintptr_t, uintptr_t>> GetSpecList();