#include "features.h"

void trigger::trigger() {
    if (IsCS2Active(true)) {
        if (cfg.trigger_enabled && IsPressed(cfg.trigger_key)) {
            uintptr_t trace = GetTracePlayer();
            int traceteam = GetTeam(trace);
            int localteam = GetTeam(GetLocalPlayer());
            int tracehp = GetHP(trace);
            if ((cfg.trigger_tc ? traceteam != localteam : true) && tracehp > 0) {
                if (CanFireActiveWep()) {
                    attack();
                }
            }
        }
    }
}
DWORD WINAPI trigger::thread(LPVOID lpParam) {
    while (true) {
        Sleep(5);
        trigger::trigger();
    }
}