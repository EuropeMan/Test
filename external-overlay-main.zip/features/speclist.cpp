#include <features.h>
uintptr_t get_pcs_player(uintptr_t address) {
    uintptr_t EntList = ReadMemory<uintptr_t>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwEntityList);
    uintptr_t list2 = ReadMemory<uintptr_t>(hProc, EntList + 0x8 * ((address & 0x7FFF) >> 9) + 16);
    return ReadMemory<uintptr_t>(hProc, list2 + 120 * (address & 0x1FF));
}

uintptr_t get_spec_player(uintptr_t controller) {
    try {
        uint64_t prepawn = ReadMemory<uint64_t>(hProc, controller + cs2_dumper::schemas::client_dll::CBasePlayerController::m_hPawn);
        uintptr_t pawn = get_pcs_player(prepawn);
        uintptr_t service = ReadMemory<uintptr_t>(hProc, pawn + cs2_dumper::schemas::client_dll::C_BasePlayerPawn::m_pObserverServices);
        uint64_t target = ReadMemory<uint64_t>(hProc, service + cs2_dumper::schemas::client_dll::CPlayer_ObserverServices::m_hObserverTarget);
        uintptr_t tpawn = get_pcs_player(target);
        return tpawn;
    }
    catch (...) {
        return 0x0;
    }
}

std::vector<std::pair<uintptr_t, uintptr_t>> GetSpecList() {
    std::vector<std::pair<uintptr_t, uintptr_t>> specList;
    std::vector<uintptr_t> players = GetAllPlayersCT();
    for (uintptr_t playerAddr : players) {
        uintptr_t specplayer = get_spec_player(playerAddr);
        if (specplayer != 0x0 && playerAddr != 0x0) {
            specList.emplace_back(playerAddr, specplayer);
        }
    }
    return specList;
}