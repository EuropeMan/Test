#pragma once
namespace trigger {
	void trigger();
	DWORD WINAPI thread(LPVOID lpParam);
}