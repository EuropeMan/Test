#pragma once
namespace wallhack {
	void Render();
}