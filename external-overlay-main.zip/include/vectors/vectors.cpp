#include <features.h>

Vec2 w2s(const Vec3& pos) {
    int width = ScreenW;
    int height = ScreenH;

    float mtx[16];
    for (int i = 0; i < 16; i++) {
        mtx[i] = ReadMemory<float>(hProc, clientBase + cs2_dumper::offsets::client_dll::dwViewMatrix + i * 4);
    }

    float screenW = mtx[12] * pos.x + mtx[13] * pos.y + mtx[14] * pos.z + mtx[15];
    if (screenW > 0.001f) {
        float screenX = mtx[0] * pos.x + mtx[1] * pos.y + mtx[2] * pos.z + mtx[3];
        float screenY = mtx[4] * pos.x + mtx[5] * pos.y + mtx[6] * pos.z + mtx[7];

        float camX = width / 2.0f;
        float camY = height / 2.0f;

        float x = camX + (camX * screenX / screenW);
        float y = camY - (camY * screenY / screenW);

        return Vec2(std::floor(x), std::floor(y));
    }

    return Vec2(-999.0f, -999.0f);
}