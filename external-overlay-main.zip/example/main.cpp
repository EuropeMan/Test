#include "../src/overlay.h"
#include <crtdbg.h>
#include <features.h>

void startthreads() {
	CreateThread(0, 0, entities::thread, 0, 0, 0);
	CreateThread(0, 0, aimbot::thread, 0, 0, 0);
	CreateThread(0, 0, trigger::thread, 0, 0, 0);
	CreateThread(0, 0, misc::thread, 0, 0, 0);
}

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	std::string text = std::string(hackname) + " - External";
	SetConsoleTitleA(text.c_str());
	HWND hWnd = GetConsoleWindow();
	ShowWindow(hWnd, SW_HIDE);
	startthreads();
	overlay::render();

	return 0;
}