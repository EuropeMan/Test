#pragma once
namespace aimbot {
	void AimBot();
	DWORD WINAPI thread(LPVOID lpParam);
}

bool find_target();
void doaim(float pitch, float yaw);
void attack();
void doautofire(LPVOID lpParam);

extern uintptr_t target;
extern bool started;
extern const char* const hitboxes[];
int GetHitbox(int hit);