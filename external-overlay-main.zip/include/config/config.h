#pragma once
struct Config {
    bool aim_enabled = false;
    bool aim_silent = false;
    bool aim_autofire = false;
    float aim_fov = 0.0f;
    bool aim_sfov = false;
    int aim_key = 0;
    int aim_smooth = 0;
    bool aim_donkill = false;
    bool aim_swhenstop = false;
    bool aim_recoilcs = false;
    bool aim_tname = false;
    bool aim_tc = true;
    int aim_hitbox = 0;


    bool trigger_enabled = false;
    int trigger_key = 0;
    bool trigger_tc = true;


    bool esp_enabled = false;
    bool esp_box = false;
    bool esp_names = false;
    bool esp_hp = false;
    bool esp_hpbar = false;
    bool esp_ctarget = false;
    bool esp_weapon = false;
    bool esp_tc = true;
    bool esp_oov = false;


    bool misc_antiflash = false;
    bool misc_bunnyhop = false;
    bool misc_wm = false;
    bool misc_sl = false;
    bool misc_slom = false;
    bool misc_hsen = false;
    int misc_hsvol = 0;


    bool darkmode = false;


    float m_yaw = 0.022f;
    float m_pitch = 0.022f;
};

extern Config cfg;
extern std::vector<std::string> configNames;
extern std::vector<const char*> configPointers;

void RefreshConfigList();
void SaveConfig(const Config& cfg, const char* filename);
bool LoadConfig(Config& cfg, const char* filename);
